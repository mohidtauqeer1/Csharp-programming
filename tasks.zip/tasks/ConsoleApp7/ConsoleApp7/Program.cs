﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Program
    {
        static int addition(int n1, int n2)
        {
            return n1+ n2;
        }
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("enter first number");
            num1 = int.Parse(Console.ReadLine());
            Console.Write("enter Second number");
            num2= int.Parse(Console.ReadLine());
            int result = addition(num1, num2);
            Console.WriteLine(result);
            Console.Read();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            int sum = 0;
            do
            {
                Console.Write("enter number:");
                num = int.Parse(Console.ReadLine());
                sum += num;
            }
            while (num != -1);
            sum += 1;
            Console.WriteLine("the total sum is {0}:",sum);
            Console.Read();
        }
    }
}

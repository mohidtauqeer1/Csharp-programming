﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = "C:\\Users\\mohid\\OneDrive\\Desktop\\tasks\\ConsoleApp8.txt";
            if (File.Exists(path))
            {
                StreamReader readfile = new StreamReader(path);
                string record;
                while ((record = readfile.ReadLine()) != null)
                {
                    Console.WriteLine(record);
                }
                readfile.Close();
            }
            else
            {
                Console.WriteLine("File not exist");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            int sum = 0;
            Console.WriteLine("enter number");
            num = int.Parse(Console.ReadLine());
            while (num!=-1)
            {
                sum += num;
                Console.WriteLine("enter number");
                num= int.Parse(Console.ReadLine());
            }
            Console.WriteLine("the total sun is {0}", sum);
            Console.Read();
        }
    }
}

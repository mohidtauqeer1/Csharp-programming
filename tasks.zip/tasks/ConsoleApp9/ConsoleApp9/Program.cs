﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = "C:\\Users\\mohid\\OneDrive\\Desktop\\tasks\\ConsoleApp8.txt";
            StreamWriter writefile = new StreamWriter(path);
            writefile.Write("my roll no is 2025-CS-500");
            writefile.Flush();
            writefile.Close();
        }
    }
}

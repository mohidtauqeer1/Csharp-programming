﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float marks;
            string input;
            Console.WriteLine("Enter the marks");
            input=Console.ReadLine();
            marks = float.Parse(input);
            if (marks>50)
            {
                Console.WriteLine("You are passed");
            }
            else
            {
                Console.WriteLine("You are failed");
            }
            Console.Read();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int age = int.Parse(Console.ReadLine());
            double washingMachinePrice = double.Parse(Console.ReadLine());
            int toyPrice = int.Parse(Console.ReadLine());
            double savedMoney = 0;
            int toyCount = 0;
            int moneyGift = 0;      
            int brotherTakes = 0;   

            for (int birthday = 1; birthday <= age; birthday++)
            {
                if (birthday % 2 == 0) 
                {
                    moneyGift += 10;       
                    savedMoney += moneyGift;
                    brotherTakes += 1;    
                }
                else 
                {
                    toyCount++;
                }
            }
            savedMoney += toyCount * toyPrice;
            savedMoney -= brotherTakes;
            if (savedMoney >= washingMachinePrice)
            {
                Console.WriteLine($"Yes! {(savedMoney - washingMachinePrice):F2}");
            }
            else
            {
                Console.WriteLine($"No! {(washingMachinePrice - savedMoney):F2}");
            }
        }
    }
}
